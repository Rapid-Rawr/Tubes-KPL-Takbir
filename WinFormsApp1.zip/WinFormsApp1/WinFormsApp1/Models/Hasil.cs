﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Models
{
    class Hasil
    {
        public string id { get; set; } // pakai Guid
        public string username { get; set; }
        public string kategori { get; set; }
        public int jumlahSoal { get; set; }
        public int jumlahBenar { get; set; }
        public DateTime waktu { get; set; }
    }
}